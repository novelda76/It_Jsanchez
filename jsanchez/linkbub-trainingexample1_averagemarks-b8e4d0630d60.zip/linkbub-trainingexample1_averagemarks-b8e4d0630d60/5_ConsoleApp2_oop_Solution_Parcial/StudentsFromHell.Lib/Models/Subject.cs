﻿namespace Academy.Lib.Models
{
    public class Subject : Entity
    {
        public string Name { get; set; }
    }
}
