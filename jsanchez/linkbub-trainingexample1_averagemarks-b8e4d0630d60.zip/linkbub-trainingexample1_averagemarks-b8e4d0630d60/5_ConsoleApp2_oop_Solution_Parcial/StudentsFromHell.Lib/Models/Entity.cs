﻿using System;

namespace Academy.Lib.Models
{
    public class Entity
    {
        public Guid Id { get; set; }
    }
}
