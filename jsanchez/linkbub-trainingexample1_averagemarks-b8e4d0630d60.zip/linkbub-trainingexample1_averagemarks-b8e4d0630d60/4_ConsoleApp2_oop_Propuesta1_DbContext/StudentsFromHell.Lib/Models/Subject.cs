﻿namespace StudentsFromHell.Lib.Models
{
    public class Subject
    {
        public string Name { get; set; }
    }
}
