﻿using Common.Lib.Core;

namespace Project.Lib.Models
{
    public class Subject : Entity
    {
        public string Name { get; set; }

        public string Teacher { get; set; }
    }
}
